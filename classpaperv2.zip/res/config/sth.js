const sth=`hi
你好`;