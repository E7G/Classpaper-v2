﻿/**告示牌 */

source_str = sth;

document.getElementById("help").innerHTML = source_str;                               